<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Pelicula;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class PeliculasController extends Controller
{
    public function index(Request $request)
    {
        //el metodo active esta definido en el model de peliculas
        // $peliculas = Pelicula::active()->orderBy($order, 'DESC')->get();
        $tipo = $request->orden;
        if($request != null){
            $peliculas = Pelicula::active()->orderBy($tipo, 'DESC')->get();
        }else{
            $peliculas = Pelicula::active()->orderBy('nombre', 'DESC')->get();
        }
        // dd($peliculas);
        $categorias = Categoria::all();

        //prueba $articulos = $categoria->articulos()->orderBy('created_at', 'desc')->paginate(5);
        return view('dashboard.peliculas.index', compact('peliculas', 'categorias'));
    }

    public function create(){
        $categorias = Categoria::all();
        return view('dashboard.peliculas.create', compact('categorias'));
    }

    public function edit(Pelicula $pelicula){
        dd($pelicula);
        $categorias = Categoria::all();
        return view('dashboard.peliculas.create', compact('pelicula','categorias'));
    }

    public function store(Request $request){
        // ddd($request);
        DB::beginTransaction();
        $pelicula = new Pelicula();
        $pelicula->nombre = $request->nombre;
        $pelicula->descripcion = $request->descripcion;
        $pelicula->anio = $request->anio;
        $pelicula->categoria_id = $request->categoria_id;
        $pelicula->save();

        DB::commit();
        Alert::success('Creada!', 'La pelicula fue creada exitosamente');
        return redirect()->route('peliculas.index');
    }

    public function update(Request $request, $id){
        DB::beginTransaction();
        $pelicula = Pelicula::findOrFail($id);
        $pelicula->nombre = $request->nombre;
        $pelicula->descripcion = $request->descripcion;
        $pelicula->anio = $request->anio;
        $pelicula->categoria_id = $request->categoria_id;
        $pelicula->update();

        DB::commit();
        Alert::success('Creada!', 'La pelicula fue creada exitosamente');
        return redirect()->back();
    }

    public function show(Request $request){

    }
    public function find(Request $request)
    {
        // $data['categorias'] = Categoria::Search($request->search)->orderBy('created_at','DESC')->paginate(8);
        // return view('config.categoria.index',$data);
        return view('dashboard.peliculas.index');
        // return view('config.categoria.index',[
        //     'categorias' => Categoria::Search($request->search)->orderBy('created_at','DESC')->paginate(8)
        // ]);
    }

}
