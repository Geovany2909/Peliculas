<?php

use App\Models\User;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PeliculasController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix'=>'dashboard','middleware' => ['auth']], function(){
    Route::get('/', function () {
        $users = User::paginate(4);
        return view('dashboard.dashboard', compact('users'));
    })->middleware(['auth'])->name('dashboard');

    Route::resource('peliculas', PeliculasController::class)->except(['index']);
    Route::get('/peliculas/{categoria?}', [PeliculasController::class, 'index'])->name('peliculas.index');
    // Route::get('/peliculas/create', [PeliculasController::class, 'create'])->name('peliculas.create');
    // Route::get('/peliculas/{categoria}/edit', [PeliculasController::class, 'edit'])->name('peliculas.edit');
    // Route::get('/peliculas/{categoria?}', [PeliculasController::class, 'index'])->name('peliculas.store');
});

require __DIR__.'/auth.php';
