@extends('admin.index')

@section('breadcrumb')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb rounded-pill">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}"><i class="bx bx-home"></i></a></li>
        <li class="breadcrumb-item active" aria-current="page">Peliculas</li>
    </ol>
</nav>
@endsection

@section('content')
<div class="row" id="table-borderless">
    <div class="col-md-12">
        <section class="search-bar-wrapper">
            <div class="search-bar">
                {{-- {!! Form::open(['url'=>['dashboard/peliculas'], 'method'=>'get']) !!}
                <fieldset class="search-input form-group position-relative">
                    {!! Form::text('search', request()->input('search'), ['class'=>'form-control rounded-right
                    form-control-lg shadow pl-2', 'placeholder'=>'Buscar','autofocus','autocomplete'=>'off']) !!}
                    <button class="btn btn-primary search-btn rounded" type="submit">
                        <span class="d-none d-sm-block">Buscar</span>
                        <i class="bx bx-search d-block d-sm-none"></i>
                    </button>
                </fieldset>
                {!! Form::close() !!} --}}

            </div>
        </section>
    </div>
    <div class="col-12">

        <div class="card">
            <div class="card-header">
                <a href="{{ route('peliculas.create') }}" class="btn btn-outline-success bx bx-plus-medical">AGREGAR
                </a>
            </div>


            <div class="card-content">
                <form action="{{ route('peliculas.index') }}" method="get">
                    <div class="col-md-6">
                        <div class="position-relative has-icon-left">
                            <select name="orden" id="orden" class="form-control" required>
                                <option value="">Ordenar Por</option>
                                <option value="nombre">NOMBRE</option>
                                <option value="anio">AÑO</option>
                                <option value="categoria_id">CATEGORIA</option>
                            </select>
                            <div class="form-control-position">
                                <i class="bx bxs-categories"></i>
                            </div>
                        </div>
                        <br>
                    </div>
                    <div class="col-md-6 d-flex justify-content-end ">
                        <button type="submit" class="btn btn-primary">Ordenar</button>
                    </div>

                </form>
                <!-- table with no border -->
                <div class="table-responsive">
                    <table class="table table-borderless mb-1">
                        <thead>
                            <tr>
                                <th>CODIGO</th>
                                <th>NOMBRE</th>
                                <th>AÑO</th>
                                <th>CATEGORIA</th>
                                <th>DESCRIPCION</th>
                                <th>ESTADO</th>
                                <th>ACCIONES</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($peliculas as $pelicula)
                            <tr>
                                <td class="text-bold-500">{{ $pelicula->id }}</td>
                                <td>{{ $pelicula->nombre }}</td>
                                <td class="text-bold-500">
                                    {{ $pelicula->anio}}
                                </td>
                                <td><a href="#">
                                        <mark>{{ $pelicula->categoria->nombre }}</mark>
                                    </a></td>
                                <td>{{ $pelicula->descripcion }}</td>
                                <td>&nbsp;&nbsp;
                                    <i class="bx bxs-circle {{ $pelicula->status == 1 ?'success':'danger'}}
                                        font-small-1 mr-50">
                                    </i>
                                </td>
                                <td>
                                    <a href="{{ route('peliculas.edit', $pelicula->id) }}" title="Editar">
                                        <i class="badge-circle badge-circle-light-secondary
                                            bx bx-edit-alt font-medium-4">
                                        </i>
                                    </a>
                                    <br><br>
                                    <a href="{{ route('peliculas.destroy', $pelicula->id) }}" title="Archivar">
                                        <i class="badge-circle badge-circle-light-secondary
                                            bx bx-archive-in font-medium-4">
                                        </i>
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('css_vendor')
<link rel="stylesheet" type="text/css" href="{{ mix('/css/vendor/swiper.min.css') }}">
@endsection

@section('css_page')
<link rel="stylesheet" type="text/css" href="{{ mix('/css/page/search.css') }}">
<link rel="stylesheet" type="text/css" href="{{ mix('/css/page/swiper.css') }}">
<link rel="stylesheet" type="text/css" href="{{ mix('/css/page/widgets.css') }}">
@endsection

@section('js_page')
<script src="{{ mix('/js/page/swiper.min.js') }}"></script>
@endsection

@section('js_custom')
<script src="{{ mix('/js/custom/page-search.js') }}"></script>
<script src="{{ mix('/js/custom/widgets.js') }}"></script>
<script>
    var select = document.getElementById('orden');
    select.addEventListener('change',function(){
        var selectedOption = this.options[select.selectedIndex];
        // location.href =   `/dashboard/peliculas/${selectedOption.value}`;
        console.log(selectedOption.value + ': ' + selectedOption.text);
    });
</script>
@endsection
