<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0">
    	<span class="float-left d-inline-block">2019 &copy; {{ config('app.name', 'Laravel') }}</span>
    	<span class="float-right d-sm-inline-block d-none">Creado
    		<i class="bx bxs-bug pink mx-50 font-small-3"></i>por
    		un reptiliano
    	</span>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
    </p>
</footer>