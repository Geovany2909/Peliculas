<?php $__env->startSection('breadcrumb'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb rounded-pill">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="bx bx-home"></i></a></li>
        <li class="breadcrumb-item active" aria-current="page">Peliculas</li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row" id="table-borderless">
    <div class="col-md-12">
        <section class="search-bar-wrapper">
            <div class="search-bar">
                

            </div>
        </section>
    </div>
    <div class="col-12">

        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(route('peliculas.create')); ?>" class="btn btn-outline-success bx bx-plus-medical">AGREGAR
                </a>
            </div>


            <div class="card-content">
                <form action="<?php echo e(route('peliculas.index')); ?>" method="get">
                    <div class="col-md-6">
                        <div class="position-relative has-icon-left">
                            <select name="orden" id="orden" class="form-control" required>
                                <option value="">Ordenar Por</option>
                                <option value="nombre">NOMBRE</option>
                                <option value="anio">AÑO</option>
                                <option value="categoria_id">CATEGORIA</option>
                            </select>
                            <div class="form-control-position">
                                <i class="bx bxs-categories"></i>
                            </div>
                        </div>
                        <br>
                    </div>
                    <div class="col-md-6 d-flex justify-content-end ">
                        <button type="submit" class="btn btn-primary">Ordenar</button>
                    </div>

                </form>
                <!-- table with no border -->
                <div class="table-responsive">
                    <table class="table table-borderless mb-1">
                        <thead>
                            <tr>
                                <th>CODIGO</th>
                                <th>NOMBRE</th>
                                <th>AÑO</th>
                                <th>CATEGORIA</th>
                                <th>DESCRIPCION</th>
                                <th>ESTADO</th>
                                <th>ACCIONES</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-bold-500"><?php echo e($pelicula->id); ?></td>
                                <td><?php echo e($pelicula->nombre); ?></td>
                                <td class="text-bold-500">
                                    <?php echo e($pelicula->anio); ?>

                                </td>
                                <td><a href="#">
                                        <mark><?php echo e($pelicula->categoria->nombre); ?></mark>
                                    </a></td>
                                <td><?php echo e($pelicula->descripcion); ?></td>
                                <td>&nbsp;&nbsp;
                                    <i class="bx bxs-circle <?php echo e($pelicula->status == 1 ?'success':'danger'); ?>

                                        font-small-1 mr-50">
                                    </i>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('peliculas.edit', $pelicula->id)); ?>" title="Editar">
                                        <i class="badge-circle badge-circle-light-secondary
                                            bx bx-edit-alt font-medium-4">
                                        </i>
                                    </a>
                                    <br><br>
                                    <a href="<?php echo e(route('peliculas.destroy', $pelicula->id)); ?>" title="Archivar">
                                        <i class="badge-circle badge-circle-light-secondary
                                            bx bx-archive-in font-medium-4">
                                        </i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_vendor'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/vendor/swiper.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_page'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/search.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/swiper.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/widgets.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_page'); ?>
<script src="<?php echo e(mix('/js/page/swiper.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_custom'); ?>
<script src="<?php echo e(mix('/js/custom/page-search.js')); ?>"></script>
<script src="<?php echo e(mix('/js/custom/widgets.js')); ?>"></script>
<script>
    var select = document.getElementById('orden');
    select.addEventListener('change',function(){
        var selectedOption = this.options[select.selectedIndex];
        // location.href =   `/dashboard/peliculas/${selectedOption.value}`;
        console.log(selectedOption.value + ': ' + selectedOption.text);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eren/Documentos/proyectoX/Peliculas/resources/views/dashboard/peliculas/index.blade.php ENDPATH**/ ?>