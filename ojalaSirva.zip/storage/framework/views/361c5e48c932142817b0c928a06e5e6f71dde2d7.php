<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="loading" data-textdirection="ltr">
<head>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Admin de sistemas.">
    <meta name="keywords" content="admin template, dashboard template, responsive admin template, web app">
    <meta name="author" content="SIAH">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="apple-touch-icon" href="/img/logo/b.png">
    <link rel="shortcut icon" type="image/x-icon" href="/img/logo/b.png">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/vendor/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/vendor/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/vendor/sweetalert2.min.css')); ?>">
    <?php echo $__env->yieldContent('css_vendor'); ?>
    <!-- END: Vendor CSS-->
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/semi-dark-layout.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/form-validation.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/theme/select2.min.css')); ?>">
    <?php echo $__env->yieldContent('css_theme'); ?>
    <!-- END: Theme CSS-->
    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/vertical-menu.css')); ?>">
    <?php echo $__env->yieldContent('css_page'); ?>
    <!-- END: Page CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/custom/style.css')); ?>">
    <?php echo $__env->yieldContent('css_custom'); ?>
    <!-- END: Custom CSS-->
</head>
<!-- END: Head-->
<!-- BEGIN: Body-->
<body class="vertical-layout vertical-menu-modern semi-dark-layout 2-columns calendar-application navbar-sticky footer-static" data-open="click" data-menu="vertical-menu-modern" data-col="content-left-sidebar">

    <script src="/acciones/msg.js"></script>
    <script src="<?php echo e(mix('/js/page/sweetalert2.all.min.js' )); ?>"></script>
    <script src="<?php echo e(mix('/js/page/polyfill.min.js' )); ?>"></script>

    <!-- BEGIN: alert float JS-->
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- END: alert float JS-->

    <?php $__env->startSection('header'); ?>
        <!-- BEGIN: Header-->
        <?php echo $__env->make('admin/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Header-->
        <!-- BEGIN: Main Menu-->
        <?php echo $__env->make('admin/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Main Menu-->
    <?php echo $__env->yieldSection(); ?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
         <div class="content-wrapper">
            <div class="content-header row">
                <div class="col-md-12 mt-2">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </div>
            </div>
            <div class="content-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <!-- END: Content-->
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <?php $__env->startSection('footer'); ?>
        <!-- BEGIN: Footer-->
        <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Footer-->
    <?php echo $__env->yieldSection(); ?>

    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(mix('/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/vendor/vendors.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js_vendor'); ?>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(mix('/js/page/select2.full.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js_page'); ?>
    <!-- END: Page JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(mix('/js/theme/app-menu.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/theme/app.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/theme/components.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/theme/footer.js')); ?>"></script>
    <?php echo $__env->yieldContent('js_theme'); ?>
    <!-- END: Theme JS-->

    <!-- BEGIN: Custom JS-->
    <script src="<?php echo e(mix('/js/custom/form-select2.js')); ?>"></script>
    <?php echo $__env->yieldContent('js_custom'); ?>
    <!-- END: Custom JS-->

</body>
</html>
<?php /**PATH /home/eren/Documentos/proyectoX/Peliculas/resources/views/admin/index.blade.php ENDPATH**/ ?>