<?php $__env->startSection('breadcrumb'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb rounded-pill">
        <li class="breadcrumb-item"><a href="/dashboard"><i class="bx bx-home"></i></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('peliculas.index')); ?>">Peliculas</a></li>
        <li class="breadcrumb-item active" aria-current="page">Creando Pelicula</li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header row">
    <div class="col-md-12 col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Crear Pelicula</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form action="<?php echo e(route('peliculas.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-6 form-group ">
                                    <label for="name">Nombre</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text" name="nombre" class="form-control" id="name"
                                            placeholder="Nombre de la pelicula" value="<?php echo e(old('name')); ?>">
                                        <div class="form-control-position">
                                            <i class="bx bx-notepad" id="view-icon"></i>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 form-group">
                                    <label for="id_category">Categoria</label>
                                    <div class="position-relative has-icon-left">
                                        <select name="categoria_id" id="categoria_id" class="form-control" required>
                                            <option value="">Seleccione una categoria</option>
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="form-control-position">
                                            <i class="bx bxs-categories"></i>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['categoria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                                
                                <div class="col-md-6 form-group">
                                    <label for="expiredDate">Fecha de estreno</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="date" name="anio"
                                        value="<?php echo e(old('anio', date('Y-m-d', strtotime('-1 week')))); ?>"
                                            id="anio" class="form-control">
                                        <div class="form-control-position">
                                            <i class="bx bx-edit-alt"></i>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['anio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="col-md-6 form-group ">
                                    <label for="name">Descripcion</label>
                                    <div class="position-relative has-icon-left">
                                        <textarea class="form-control" name="descripcion" id="label-textarea" rows="3"
                                            placeholder="Descripción"><?php echo e(old('descripcion')); ?></textarea>
                                        <div class="form-control-position">
                                            <i class="bx bx-notepad" id="view-icon"></i>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-12 d-flex justify-content-end ">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_vendor'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/vendor/swiper.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(mix('css/vendor/jquery.bootstrap-touchspin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_page'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/search.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/page/swiper.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_page'); ?>
<script src="<?php echo e(mix('/js/page/swiper.min.js')); ?>"></script>
<script src="<?php echo e(mix('/js/page/jquery.bootstrap-touchspin.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_custom'); ?>
<script src="<?php echo e(mix('/js/custom/page-search.js')); ?>"></script>
<script src="<?php echo e(mix('/js/custom/number-input.js')); ?>"></script>
<script src="/acciones/producto.js"></script>
<script>
    $("input[name='stocks']").TouchSpin({
        min: 1,
        max: 100000,
        step: 1,
        decimals: 0,
        boostat: 5,
        maxboostedstep: 10,
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eren/Documentos/proyectoX/Peliculas/resources/views/dashboard/peliculas/create.blade.php ENDPATH**/ ?>