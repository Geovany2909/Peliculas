<?php $__currentLoopData = ['warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Session::has('alert-' . $msg)): ?>
<script type="text/javascript">
	Swal.fire({ 
		title: "", 
		text: "<?php echo e(Session::get('alert-' . $msg)); ?>", 
		type: "<?php echo e($msg); ?>", 
		confirmButtonClass: "btn btn-primary", 
		buttonsStyling: !1 
	})
</script>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = ['error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Session::has('alert-' . $msg)): ?>
<script type="text/javascript">
	Swal.fire({	
		title: "Error!", 
		text: "<?php echo e(Session::get('alert-' . $msg)); ?>", 
		type: "<?php echo e($msg); ?>", 
		confirmButtonClass: "btn btn-primary", 
		buttonsStyling: !1 
	})
</script>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($errors->any()): ?>
<script type="text/javascript">
	Swal.fire({	
		title: "Error!", 
		text: "Revise la información ingresados", 
		type: "error", 
		confirmButtonClass: "btn btn-primary", 
		buttonsStyling: !1 
	})
</script>
<?php endif; ?><?php /**PATH /home/eren/Documentos/proyectoX/Peliculas/resources/views/admin/alert.blade.php ENDPATH**/ ?>